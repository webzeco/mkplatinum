import React from "react";

export  const ProductDetailContext= React.createContext();